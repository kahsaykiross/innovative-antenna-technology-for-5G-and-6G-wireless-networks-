"""HFSS/CST sweep stub.
This script is a template to automate EM param sweeps. Replace the `run_em_sim` function
with calls to HFSS (pyansys) or CST (pycst) APIs available in your environment.
"""

import argparse, json, time


def run_em_sim(params, out_file):
    # Placeholder: write params to JSON (simulate a result)
    result = {
        'params': params,
        's11_db': -10.0 - 5.0 * (0.5 - params.get('tune',0.5)),
        'gain_dbi': 12.0 + 3.0 * params.get('scale',1.0)
    }
    with open(out_file, 'w') as f:
        json.dump(result, f, indent=2)
    time.sleep(0.2)
    return out_file

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', default='em/results/sim_result.json')
    parser.add_argument('--tune', type=float, default=0.5)
    parser.add_argument('--scale', type=float, default=1.0)
    args = parser.parse_args()
    Path = __import__('pathlib').Path
    Path('em/results').mkdir(parents=True, exist_ok=True)
    run_em_sim({'tune':args.tune,'scale':args.scale}, args.out)
    print('Wrote', args.out)
