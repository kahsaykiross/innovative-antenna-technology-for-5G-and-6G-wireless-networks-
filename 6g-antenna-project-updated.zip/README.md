# 6G Antenna Project

This repository contains simulation and experimental scaffolds for innovative 6G antenna development.

## Quickstart
1. Create conda env: `conda env create -f environment.yml`
2. Or install pip requirements: `pip install -r requirements.txt`
3. Run baseline OFDM sim: `python link_level/link_sim.py` (generates analysis/ofdm_baseline.png)
4. GNN train: `python ml/gnn/train.py` (simple stub)

## HFSS/CST automation
- `em/hfss_parametric_patch.py` is a detailed PyAEDT template. Run on a machine with Ansys AEDT and pyAEDT installed.
- `em/cst_parametric_patch.py` is a CST scripting placeholder.

## Docker
- Build: `docker build -t 6g-antenna .`
- The provided Dockerfile installs Python deps and copies the repo.

## GitHub Actions
A workflow is provided in `.github/workflows/ci.yml` to run basic linters and tests.

