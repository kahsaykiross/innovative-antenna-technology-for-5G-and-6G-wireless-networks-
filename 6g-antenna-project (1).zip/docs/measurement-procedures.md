# Measurement Procedures (high-level)
1. Calibrate VNA, Spectrum Analyzer, Power Meter
2. Measure element S-parameters and store in em/sparams/
3. Run EM sweeps: python em/em_sweep.py --tune 0.5 --scale 1.0
4. Chamber array pattern scans
5. OTA link capture using ota/measurement_logger.py (not included)
