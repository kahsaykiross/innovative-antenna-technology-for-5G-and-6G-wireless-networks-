# 6G Antenna Project - Scaffold
This repo contains simulation and experimental scaffolds for innovative 6G antenna development.
See folders: em/, link_level/, ml/, ota/, analysis/
Run `docker build -t 6g-antenna .` to build the dev container.
