import torch
import torch.nn as nn
try:
    from torch_geometric.nn import GCNConv
except Exception:
    # Fallback minimal conv
    class GCNConv(nn.Module):
        def __init__(self, a,b):
            super().__init__(); self.lin=nn.Linear(a,b)
        def forward(self,x,edge_index=None): return self.lin(x)

class SimpleGNN(nn.Module):
    def __init__(self, in_dim, hidden=64, out_dim=128):
        super().__init__()
        self.conv1 = GCNConv(in_dim, hidden)
        self.conv2 = GCNConv(hidden, out_dim)

    def forward(self, x, edge_index=None):
        x = self.conv1(x, edge_index)
        x = torch.relu(x)
        x = self.conv2(x, edge_index)
        return x
