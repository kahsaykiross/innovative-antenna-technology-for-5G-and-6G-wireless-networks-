# hfss_parametric_patch.py -- PyAEDT (Ansys AEDT) template
# NOTE: This script requires Ansys AEDT installed and pyansys/pyAEDT available in the environment.
# It performs a parametric sweep over patch length and outputs S-parameters and far-field patterns.
#
# Usage (on AEDT-capable machine):
#   python hfss_parametric_patch.py --project project.aedt --design patch_sweep --start 0.016 --stop 0.02 --steps 5
#
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', default='patch_sweep.aedt')
    parser.add_argument('--design', default='patch_sweep')
    parser.add_argument('--start', type=float, default=0.016)
    parser.add_argument('--stop', type=float, default=0.02)
    parser.add_argument('--steps', type=int, default=5)
    args = parser.parse_args()
    print('This is a template. To run, install pyAEDT and run on a machine with Ansys AEDT.')
    print(f'Would sweep patch length from {args.start} to {args.stop} in {args.steps} steps and save S-params and far fields.')

if __name__=='__main__':
    main()
