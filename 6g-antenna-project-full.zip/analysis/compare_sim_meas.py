# Simple comparator to load JSON EM sim results and make a small report
import json,glob
import matplotlib.pyplot as plt
files = glob.glob('em/results/*.json')
gains=[]
for f in files:
    with open(f) as fh:
        d=json.load(fh); gains.append(d.get('gain_dbi',0))
if gains:
    plt.plot(gains,'-o'); plt.xlabel('sim idx'); plt.ylabel('gain dBi'); plt.grid(True)
    plt.savefig('analysis/gain_trace.png'); print('Saved analysis/gain_trace.png')
else:
    print('No em/results/*.json found')
