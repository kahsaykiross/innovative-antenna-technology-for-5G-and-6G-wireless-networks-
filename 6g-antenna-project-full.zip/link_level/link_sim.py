"""Simple link-level OFDM baseline simulation.
Run: python link_level/link_sim.py
"""

import numpy as np
import matplotlib.pyplot as plt

class OFDMSim:
    def __init__(self, fc=28e9, bw=200e6, n_subcarriers=1024):
        self.fc = fc
        self.bw = bw
        self.n_sub = n_subcarriers

    def generate_ofdm(self, n_symbols=10):
        return (np.random.randn(n_symbols, self.n_sub) + 1j*np.random.randn(n_symbols, self.n_sub))

    def awgn(self, x, snr_db):
        sigp = np.mean(np.abs(x)**2)
        noise_p = sigp / (10**(snr_db/10))
        noise = np.sqrt(noise_p/2) * (np.random.randn(*x.shape) + 1j*np.random.randn(*x.shape))
        return x + noise

def main():
    sim = OFDMSim()
    tx = sim.generate_ofdm(20)
    snrs = [0,5,10,15,20,25]
    bers = []
    for s in snrs:
        rx = sim.awgn(tx, s)
        # crude metric: error power fraction
        err = np.mean(np.abs(rx-tx)**2)/np.mean(np.abs(tx)**2)
        bers.append(err)
    import matplotlib.pyplot as plt
    plt.semilogy(snrs, bers, marker='o')
    plt.xlabel('SNR (dB)')
    plt.ylabel('Normalized MSE')
    plt.grid(True)
    plt.title('Baseline OFDM sim (toy)')
    plt.tight_layout()
    plt.savefig('analysis/ofdm_baseline.png')
    print('Saved analysis/ofdm_baseline.png')

if __name__ == '__main__':
    Path = __import__('pathlib').Path
    Path('analysis').mkdir(parents=True, exist_ok=True)
    main()
