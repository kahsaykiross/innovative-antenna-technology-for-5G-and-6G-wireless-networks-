# Minimal training stub for GNN on synthetic data
import torch
from .model import SimpleGNN
def synthetic_dataset(n_nodes=16, in_dim=4):
    import numpy as np
    x = torch.tensor(np.random.randn(n_nodes,in_dim), dtype=torch.float32)
    return x
def train():
    model = SimpleGNN(4,32,8)
    x = synthetic_dataset()
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    for ep in range(10):
        out = model(x)
        loss = ((out**2).sum())*1e-3
        opt.zero_grad(); loss.backward(); opt.step()
        print(f'ep {ep} loss {loss.item():.6f}')
if __name__=='__main__':
    train()
